package vista;

import conexion.Conexion;
import crud.GastoCRUD;
import crud.SalarioCRUD;
import crud.UsuarioCRUD;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import crud.ResumenFinanciero;

public class MenuPrincipal extends JFrame {

    public MenuPrincipal() {
        setTitle("Control de Sueldo Personal");
        setSize(800, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // ── Panel de encabezado ──
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(00,00,00));
        header.setPreferredSize(new Dimension(800, 90));

        JLabel lblTitulo = new JLabel("CONTROL DE SUELDO PERSONAL", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitulo.setForeground(Color.WHITE);

        JLabel lblSubtitulo = new JLabel("Gestiona tu salario y controla tus gastos", SwingConstants.CENTER);
        lblSubtitulo.setFont(new Font("Segoe UI", Font.ITALIC, 13));
        lblSubtitulo.setForeground(new Color(186, 230, 253));

        JPanel headerText = new JPanel(new GridLayout(2, 1));
        headerText.setOpaque(false);
        headerText.add(lblTitulo);
        headerText.add(lblSubtitulo);
        header.add(headerText, BorderLayout.CENTER);
        add(header, BorderLayout.NORTH);

        // ── Panel lateral de menú ──
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(new Color(15, 23, 42));
        sidebar.setPreferredSize(new Dimension(200, 460));
        sidebar.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));

        JLabel lblMenu = new JLabel("MENÚ PRINCIPAL");
        lblMenu.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblMenu.setForeground(new Color(100, 116, 139));
        lblMenu.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(lblMenu);
        sidebar.add(Box.createVerticalStrut(15));

        String[][] botones = {
            {"Usuarios",    "usuarios"},
            {"Salarios",    "salarios"},
            {"Gastos",      "gastos"},
            {"Resumen",     "resumen"},
        };

        for (String[] b : botones) {
            JButton btn = crearBotonMenu(b[0], b[1]);
            sidebar.add(btn);
            sidebar.add(Box.createVerticalStrut(8));
        }

        sidebar.add(Box.createVerticalGlue());

        JButton btnSalir = crearBotonMenu("Salir", "salir");
        btnSalir.setBackground(new Color(127, 29, 29));
        sidebar.add(btnSalir);

        add(sidebar, BorderLayout.WEST);

        // ── Panel central (bienvenida) ──
        JPanel centro = panelBienvenida();
        add(centro, BorderLayout.CENTER);

        // ── Barra de estado ──
        JLabel status = new JLabel("Sistema listo — SQLite conectado", SwingConstants.LEFT);
        status.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        status.setForeground(new Color(34, 197, 94));
        status.setBackground(new Color(2, 6, 23));
        status.setOpaque(true);
        status.setPreferredSize(new Dimension(800, 25));
        add(status, BorderLayout.SOUTH);

        // Inicializa conexión al arrancar
        Conexion.getConexion();
    }

    // ── Botón del menú lateral ──
    private JButton crearBotonMenu(String texto, String accion) {
        JButton btn = new JButton(texto);
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setMaximumSize(new Dimension(180, 40));
        btn.setPreferredSize(new Dimension(180, 40));
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(30, 41, 59));
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setHorizontalAlignment(SwingConstants.LEFT);

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (!accion.equals("salir"))
                    btn.setBackground(new Color(30, 58, 138));
                else
                    btn.setBackground(new Color(185, 28, 28));
            }
            public void mouseExited(MouseEvent e) {
                if (!accion.equals("salir"))
                    btn.setBackground(new Color(30, 41, 59));
                else
                    btn.setBackground(new Color(127, 29, 29));
            }
        });

        btn.addActionListener(e -> navegarA(accion));
        return btn;
    }

    // ── Navegación ──
    private void navegarA(String destino) {
        switch (destino) {
            case "usuarios" -> new UsuarioCRUD().setVisible(true);
            case "salarios" -> new SalarioCRUD().setVisible(true);
            case "gastos"   -> new GastoCRUD().setVisible(true);
            case "resumen"  -> new ResumenFinanciero().setVisible(true);
            case "salir"    -> {
                int op = JOptionPane.showConfirmDialog(this,
                    "¿Deseas cerrar la aplicación?", "Cerrar sesión",
                    JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (op == JOptionPane.YES_OPTION) {
                    Conexion.cerrarConexion();
                    JOptionPane.showMessageDialog(this,
                        "¡Hasta pronto!.",
                        "Cerrar sesión", JOptionPane.INFORMATION_MESSAGE);
                    System.exit(0);
                }
            }
        }
    }

    // ── Panel de bienvenida ──
    private JPanel panelBienvenida() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(new Color(248, 250, 252));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.insets = new Insets(5, 10, 5, 10);

        JLabel ico = new JLabel("💰", SwingConstants.CENTER);
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 64));
        p.add(ico, gbc);

        gbc.gridy = 1;
        JLabel t1 = new JLabel("Bienvenido al Control de Sueldo", SwingConstants.CENTER);
        t1.setFont(new Font("Segoe UI", Font.BOLD, 20));
        t1.setForeground(new Color(30, 58, 138));
        p.add(t1, gbc);

        gbc.gridy = 2;
        JLabel t2 = new JLabel("Selecciona una opción del menú lateral para comenzar.", SwingConstants.CENTER);
        t2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        t2.setForeground(new Color(100, 116, 139));
        p.add(t2, gbc);

        gbc.gridy = 3;
        gbc.insets = new Insets(20, 10, 5, 10);
        JLabel t3 = new JLabel("Funcionalidades disponibles:", SwingConstants.CENTER);
        t3.setFont(new Font("Segoe UI", Font.BOLD, 13));
        t3.setForeground(new Color(51, 65, 85));
        p.add(t3, gbc);

        String[] items = {
            " Gestión de Usuarios",
            " Registro de Salarios mensuales",
            " Control de Gastos por categoría",
            " Resumen financiero con balance"
        };
        for (String item : items) {
            gbc.gridy++;
            gbc.insets = new Insets(2, 10, 2, 10);
            JLabel li = new JLabel(item, SwingConstants.CENTER);
            li.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            li.setForeground(new Color(71, 85, 105));
            p.add(li, gbc);
        }
        return p;
    }
}
