package crud;

import conexion.Conexion;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class ResumenFinanciero extends JFrame {

    private JComboBox<String> cmbUsuario;
    private JComboBox<String> cmbMes;
    private JTextField txtAnio;
    private JLabel lblSalarioNeto, lblTotalGastos, lblBalance, lblEstado;
    private JTextArea areaDetalle;

    private static final String[] MESES = {
        "Enero","Febrero","Marzo","Abril","Mayo","Junio",
        "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"
    };

    public ResumenFinanciero() {
        setTitle("Resumen Financiero");
        setSize(750, 580);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(248, 250, 252));

        add(headerPanel(), BorderLayout.NORTH);
        add(filtrosPanel(), BorderLayout.WEST);
        add(resultadosPanel(), BorderLayout.CENTER);

        cargarUsuarios();
    }

    private JPanel headerPanel() {
        JPanel p = new JPanel();
        p.setBackground(new Color(88, 28, 135));
        p.setPreferredSize(new Dimension(750, 50));
        JLabel lbl = new JLabel("RESUMEN FINANCIERO PERSONAL", SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl.setForeground(Color.WHITE);
        p.add(lbl);
        return p;
    }

    private JPanel filtrosPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(88, 28, 135)),
            "  Filtros  ", 0, 0,
            new Font("Segoe UI", Font.BOLD, 12), new Color(88, 28, 135)));
        p.setBackground(Color.WHITE);
        p.setPreferredSize(new Dimension(200, 300));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 4, 8);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.gridx = 0;

        g.gridy = 0; p.add(new JLabel("Usuario:"), g);
        g.gridy = 1;
        cmbUsuario = new JComboBox<>();
        cmbUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(cmbUsuario, g);

        g.gridy = 2; p.add(new JLabel("Mes:"), g);
        g.gridy = 3;
        cmbMes = new JComboBox<>(MESES);
        cmbMes.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(cmbMes, g);

        g.gridy = 4; p.add(new JLabel("Año:"), g);
        g.gridy = 5;
        txtAnio = new JTextField("2026", 8);
        txtAnio.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(txtAnio, g);

        g.gridy = 6;
        g.insets = new Insets(16, 8, 4, 8);
        JButton btnCalcular = new JButton("Calcular");
        btnCalcular.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnCalcular.setBackground(new Color(88, 28, 135));
        btnCalcular.setForeground(Color.WHITE);
        btnCalcular.setFocusPainted(false);
        btnCalcular.setBorderPainted(false);
        btnCalcular.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCalcular.addActionListener(e -> calcularResumen());
        p.add(btnCalcular, g);

        return p;
    }

    private JPanel resultadosPanel() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(new Color(248, 250, 252));
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Tarjetas de resultados
        JPanel tarjetas = new JPanel(new GridLayout(2, 2, 10, 10));
        tarjetas.setBackground(new Color(248, 250, 252));
        tarjetas.setPreferredSize(new Dimension(500, 160));

        lblSalarioNeto = crearTarjeta(tarjetas, "Salario Neto", "$0.00", new Color(21, 128, 61));
        lblTotalGastos = crearTarjeta(tarjetas, "Total Gastos", "$0.00", new Color(185, 28, 28));
        lblBalance     = crearTarjeta(tarjetas, "Balance", "$0.00", new Color(30, 58, 138));
        lblEstado      = crearTarjeta(tarjetas, "Estado", "—", new Color(88, 28, 135));

        p.add(tarjetas, BorderLayout.NORTH);

        // Detalle de gastos por categoría
        areaDetalle = new JTextArea();
        areaDetalle.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaDetalle.setEditable(false);
        areaDetalle.setBackground(new Color(15, 23, 42));
        areaDetalle.setForeground(new Color(134, 239, 172));
        areaDetalle.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        areaDetalle.setText("  Selecciona usuario, mes y año, luego presiona Calcular");

        JScrollPane sp = new JScrollPane(areaDetalle);
        sp.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(88, 28, 135)),
            "  Detalle de Gastos por Categoría  ", 0, 0,
            new Font("Segoe UI", Font.BOLD, 12), new Color(88, 28, 135)));
        p.add(sp, BorderLayout.CENTER);

        return p;
    }

    private JLabel crearTarjeta(JPanel parent, String titulo, String valor, Color color) {
        JPanel tarjeta = new JPanel(new BorderLayout());
        tarjeta.setBackground(color);
        tarjeta.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));

        JLabel lblTit = new JLabel(titulo, SwingConstants.CENTER);
        lblTit.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblTit.setForeground(new Color(255, 255, 255, 180));

        JLabel lblVal = new JLabel(valor, SwingConstants.CENTER);
        lblVal.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblVal.setForeground(Color.WHITE);

        tarjeta.add(lblTit, BorderLayout.NORTH);
        tarjeta.add(lblVal, BorderLayout.CENTER);
        parent.add(tarjeta);
        return lblVal;
    }

    private void cargarUsuarios() {
        try (Statement st = Conexion.getConexion().createStatement();
             ResultSet rs = st.executeQuery("SELECT id, nombre FROM usuarios ORDER BY nombre")) {
            while (rs.next()) {
                cmbUsuario.addItem(rs.getInt("id") + " - " + rs.getString("nombre"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void calcularResumen() {
        if (cmbUsuario.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un usuario."); return;
        }
        int userId = Integer.parseInt(cmbUsuario.getSelectedItem().toString().split(" - ")[0]);
        String mes = cmbMes.getSelectedItem().toString();
        int anio;
        try { anio = Integer.parseInt(txtAnio.getText().trim()); }
        catch (NumberFormatException ex) { JOptionPane.showMessageDialog(this, "Año inválido."); return; }

        // Salario neto
        double salarioNeto = 0;
        String sqlSalario = "SELECT salario_neto FROM salarios WHERE usuario_id=? AND mes=? AND anio=?";
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement(sqlSalario)) {
            ps.setInt(1, userId); ps.setString(2, mes); ps.setInt(3, anio);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) salarioNeto = rs.getDouble("salario_neto");
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Error: " + e.getMessage()); }

        // Total gastos y desglose
        double totalGastos = 0;
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("  %-22s  %10s%n", "CATEGORÍA", "MONTO"));
        sb.append("  " + "─".repeat(36) + "\n");

        String sqlGastos = """
            SELECT categoria, SUM(monto) as total
            FROM gastos WHERE usuario_id=? AND mes=? AND anio=?
            GROUP BY categoria ORDER BY total DESC
            """;
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement(sqlGastos)) {
            ps.setInt(1, userId); ps.setString(2, mes); ps.setInt(3, anio);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                double t = rs.getDouble("total");
                totalGastos += t;
                sb.append(String.format("  %-22s  $%,10.2f%n", rs.getString("categoria"), t));
            }
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Error: " + e.getMessage()); }

        sb.append("  " + "─".repeat(36) + "\n");
        sb.append(String.format("  %-22s  $%,10.2f%n", "TOTAL GASTOS", totalGastos));

        double balance = salarioNeto - totalGastos;
        sb.append("\n");
        sb.append(String.format("  %-22s  $%,10.2f%n", "SALARIO NETO", salarioNeto));
        sb.append(String.format("  %-22s  $%,10.2f%n", "BALANCE FINAL", balance));

        // Actualizar tarjetas
        lblSalarioNeto.setText(String.format("$%,.2f", salarioNeto));
        lblTotalGastos.setText(String.format("$%,.2f", totalGastos));
        lblBalance.setText(String.format("$%,.2f", balance));

        if (balance >= 0) {
            lblEstado.setText("Superávit");
        } else {
            lblEstado.setText("Déficit");
        }

        areaDetalle.setText(sb.toString());
    }
}
