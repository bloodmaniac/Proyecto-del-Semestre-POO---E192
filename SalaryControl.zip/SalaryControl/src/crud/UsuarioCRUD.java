package crud;

import conexion.Conexion;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class UsuarioCRUD extends JFrame {

    private JTextField txtNombre, txtCedula, txtCorreo;
    private JPasswordField txtContrasena;
    private JTable tabla;
    private DefaultTableModel modelo;
    private int idSeleccionado = -1;

    public UsuarioCRUD() {
        setTitle("Gestión de Usuarios");
        setSize(860, 560);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(248, 250, 252));

        add(headerPanel(), BorderLayout.NORTH);
        add(formularioPanel(), BorderLayout.WEST);
        add(tablaPanel(), BorderLayout.CENTER);
        add(botonesPanel(), BorderLayout.SOUTH);

        cargarDatos();
    }

    private JPanel headerPanel() {
        JPanel p = new JPanel();
        p.setBackground(new Color(30, 58, 138));
        p.setPreferredSize(new Dimension(860, 50));
        JLabel lbl = new JLabel("GESTIÓN DE USUARIOS", SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl.setForeground(Color.WHITE);
        p.add(lbl);
        return p;
    }

    private JPanel formularioPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(30, 58, 138)),
            "  Datos del Usuario  ", 0, 0,
            new Font("Segoe UI", Font.BOLD, 12), new Color(30, 58, 138)));
        p.setBackground(Color.WHITE);
        p.setPreferredSize(new Dimension(230, 400));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(6, 8, 4, 8);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.gridx = 0;

        txtNombre    = addCampo(p, g, 0, "Nombre completo:");
        txtCedula    = addCampo(p, g, 1, "Cédula:");
        txtCorreo    = addCampo(p, g, 2, "Correo:");
        txtContrasena = new JPasswordField(15);
        g.gridy = 6;
        p.add(new JLabel("Contraseña:"), g);
        g.gridy = 7;
        txtContrasena.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(txtContrasena, g);

        return p;
    }

    private JTextField addCampo(JPanel p, GridBagConstraints g, int fila, String label) {
        g.gridy = fila * 2;
        p.add(new JLabel(label), g);
        g.gridy = fila * 2 + 1;
        JTextField tf = new JTextField(15);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(tf, g);
        return tf;
    }

    private JScrollPane tablaPanel() {
        modelo = new DefaultTableModel(
            new String[]{"ID", "Nombre", "Cédula", "Correo", "Fecha Registro"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(modelo);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(new Color(30, 58, 138));
        tabla.getTableHeader().setForeground(Color.black);
        tabla.setSelectionBackground(new Color(219, 234, 254));

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                int row = tabla.getSelectedRow();
                idSeleccionado = Integer.parseInt(modelo.getValueAt(row, 0).toString());
                txtNombre.setText(modelo.getValueAt(row, 1).toString());
                txtCedula.setText(modelo.getValueAt(row, 2).toString());
                txtCorreo.setText(modelo.getValueAt(row, 3).toString());
                txtContrasena.setText("");
            }
        });

        JScrollPane sp = new JScrollPane(tabla);
        sp.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(30, 58, 138)),
            "  Lista de Usuarios  ", 0, 0,
            new Font("Segoe UI", Font.BOLD, 12), new Color(30, 58, 138)));
        return sp;
    }

    private JPanel botonesPanel() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        p.setBackground(new Color(248, 250, 252));

        p.add(crearBtn("Agregar",    new Color(21, 128, 61),  e -> insertar()));
        p.add(crearBtn("Actualizar", new Color(146, 64, 14),  e -> actualizar()));
        p.add(crearBtn("Eliminar",   new Color(185, 28, 28),  e -> eliminar()));
        p.add(crearBtn("Limpiar",    new Color(30, 58, 138),  e -> limpiar()));
        return p;
    }

    private JButton crearBtn(String texto, Color color, java.awt.event.ActionListener al) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(130, 36));
        b.addActionListener(al);
        return b;
    }

    // ── CRUD ──
    private void cargarDatos() {
        modelo.setRowCount(0);
        String sql = "SELECT id, nombre, cedula, correo, fecha_reg FROM usuarios ORDER BY id";
        try (Statement st = Conexion.getConexion().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id"), rs.getString("nombre"),
                    rs.getString("cedula"), rs.getString("correo"),
                    rs.getString("fecha_reg")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar: " + e.getMessage());
        }
    }

    private void insertar() {
        if (txtNombre.getText().isBlank() || txtCedula.getText().isBlank() ||
            txtContrasena.getPassword().length == 0) {
            JOptionPane.showMessageDialog(this, "Nombre, cédula y contraseña son obligatorios.");
            return;
        }
        String sql = "INSERT INTO usuarios (nombre, cedula, correo, contrasena) VALUES (?,?,?,?)";
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement(sql)) {
            ps.setString(1, txtNombre.getText().trim());
            ps.setString(2, txtCedula.getText().trim());
            ps.setString(3, txtCorreo.getText().trim());
            ps.setString(4, new String(txtContrasena.getPassword()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Usuario agregado correctamente.");
            limpiar(); cargarDatos();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void actualizar() {
        if (idSeleccionado < 0) { JOptionPane.showMessageDialog(this, "Selecciona un usuario."); return; }
        String sql = "UPDATE usuarios SET nombre=?, cedula=?, correo=? WHERE id=?";
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement(sql)) {
            ps.setString(1, txtNombre.getText().trim());
            ps.setString(2, txtCedula.getText().trim());
            ps.setString(3, txtCorreo.getText().trim());
            ps.setInt(4, idSeleccionado);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Usuario actualizado.");
            limpiar(); cargarDatos();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void eliminar() {
        if (idSeleccionado < 0) { JOptionPane.showMessageDialog(this, "Selecciona un usuario."); return; }
        int op = JOptionPane.showConfirmDialog(this,
            "¿Eliminar usuario con ID " + idSeleccionado + "?",
            "Confirmar", JOptionPane.YES_NO_OPTION);
        if (op != JOptionPane.YES_OPTION) return;
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement(
                "DELETE FROM usuarios WHERE id=?")) {
            ps.setInt(1, idSeleccionado);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Usuario eliminado.");
            limpiar(); cargarDatos();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void limpiar() {
        txtNombre.setText(""); txtCedula.setText("");
        txtCorreo.setText(""); txtContrasena.setText("");
        idSeleccionado = -1;
        tabla.clearSelection();
    }
}
