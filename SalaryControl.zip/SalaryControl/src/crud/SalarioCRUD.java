package crud;

import conexion.Conexion;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class SalarioCRUD extends JFrame {

    private JComboBox<String> cmbUsuario;
    private JComboBox<String> cmbMes;
    private JTextField txtAnio, txtSalarioBase, txtBonificacion, txtDeducciones;
    private JLabel lblNeto;
    private JTable tabla;
    private DefaultTableModel modelo;
    private int idSeleccionado = -1;

    private final String[] MESES = {
        "Enero","Febrero","Marzo","Abril","Mayo","Junio",
        "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"
    };

    public SalarioCRUD() {
        setTitle("💵 Registro de Salarios");
        setSize(900, 580);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(248, 250, 252));

        add(headerPanel(), BorderLayout.NORTH);
        add(formularioPanel(), BorderLayout.WEST);
        add(tablaPanel(), BorderLayout.CENTER);
        add(botonesPanel(), BorderLayout.SOUTH);

        cargarUsuarios();
        cargarDatos();
    }

    private JPanel headerPanel() {
        JPanel p = new JPanel();
        p.setBackground(new Color(21, 128, 61));
        p.setPreferredSize(new Dimension(900, 50));
        JLabel lbl = new JLabel("REGISTRO DE SALARIOS MENSUALES", SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl.setForeground(Color.WHITE);
        p.add(lbl);
        return p;
    }

    private JPanel formularioPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(21, 128, 61)),
            "  Datos del Salario  ", 0, 0,
            new Font("Segoe UI", Font.BOLD, 12), new Color(21, 128, 61)));
        p.setBackground(Color.WHITE);
        p.setPreferredSize(new Dimension(240, 420));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 8, 3, 8);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.gridx = 0;

        // Usuario
        g.gridy = 0; p.add(new JLabel("Usuario:"), g);
        g.gridy = 1;
        cmbUsuario = new JComboBox<>();
        cmbUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(cmbUsuario, g);

        // Mes
        g.gridy = 2; p.add(new JLabel("Mes:"), g);
        g.gridy = 3;
        cmbMes = new JComboBox<>(MESES);
        cmbMes.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(cmbMes, g);

        // Año
        g.gridy = 4; p.add(new JLabel("Año:"), g);
        g.gridy = 5; txtAnio = new JTextField("2026", 10); p.add(txtAnio, g);

        // Salario base
        g.gridy = 6; p.add(new JLabel("Salario base ($):"), g);
        g.gridy = 7; txtSalarioBase = new JTextField("0.00", 10); p.add(txtSalarioBase, g);

        // Bonificación
        g.gridy = 8; p.add(new JLabel("Bonificación ($):"), g);
        g.gridy = 9; txtBonificacion = new JTextField("0.00", 10); p.add(txtBonificacion, g);

        // Deducciones
        g.gridy = 10; p.add(new JLabel("Deducciones ($):"), g);
        g.gridy = 11; txtDeducciones = new JTextField("0.00", 10); p.add(txtDeducciones, g);

        // Neto calculado
        g.gridy = 12;
        g.insets = new Insets(12, 8, 3, 8);
        JLabel lblEtiq = new JLabel("Salario neto:");
        lblEtiq.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblEtiq.setForeground(new Color(21, 128, 61));
        p.add(lblEtiq, g);

        g.gridy = 13;
        lblNeto = new JLabel("$0.00", SwingConstants.CENTER);
        lblNeto.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblNeto.setForeground(new Color(21, 128, 61));
        lblNeto.setBackground(new Color(220, 252, 231));
        lblNeto.setOpaque(true);
        lblNeto.setBorder(BorderFactory.createEmptyBorder(4, 0, 4, 0));
        p.add(lblNeto, g);

        // Calcular al perder foco
        for (JTextField tf : new JTextField[]{txtSalarioBase, txtBonificacion, txtDeducciones}) {
            tf.addFocusListener(new java.awt.event.FocusAdapter() {
                public void focusLost(java.awt.event.FocusEvent e) { calcularNeto(); }
            });
        }

        return p;
    }

    private void calcularNeto() {
        try {
            double base  = Double.parseDouble(txtSalarioBase.getText().replace(",", "."));
            double boni  = Double.parseDouble(txtBonificacion.getText().replace(",", "."));
            double dedu  = Double.parseDouble(txtDeducciones.getText().replace(",", "."));
            lblNeto.setText(String.format("$%.2f", base + boni - dedu));
        } catch (NumberFormatException ex) {
            lblNeto.setText("$0.00");
        }
    }

    private JScrollPane tablaPanel() {
        modelo = new DefaultTableModel(
            new String[]{"ID", "Usuario", "Mes", "Año", "Base", "Bonif.", "Deducc.", "Neto"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(modelo);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(new Color(21, 128, 61));
        tabla.getTableHeader().setForeground(Color.black);
        tabla.setSelectionBackground(new Color(220, 252, 231));

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                int row = tabla.getSelectedRow();
                idSeleccionado = Integer.parseInt(modelo.getValueAt(row, 0).toString());
                cmbMes.setSelectedItem(modelo.getValueAt(row, 2).toString());
                txtAnio.setText(modelo.getValueAt(row, 3).toString());
                txtSalarioBase.setText(modelo.getValueAt(row, 4).toString());
                txtBonificacion.setText(modelo.getValueAt(row, 5).toString());
                txtDeducciones.setText(modelo.getValueAt(row, 6).toString());
                calcularNeto();
            }
        });

        JScrollPane sp = new JScrollPane(tabla);
        sp.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(21, 128, 61)),
            "  Historial de Salarios  ", 0, 0,
            new Font("Segoe UI", Font.BOLD, 12), new Color(21, 128, 61)));
        return sp;
    }

    private JPanel botonesPanel() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        p.setBackground(new Color(248, 250, 252));
        p.add(crearBtn("Registrar",  new Color(21, 128, 61),  e -> insertar()));
        p.add(crearBtn("Actualizar", new Color(146, 64, 14),  e -> actualizar()));
        p.add(crearBtn("Eliminar",   new Color(185, 28, 28),  e -> eliminar()));
        p.add(crearBtn("Limpiar",    new Color(30, 58, 138),  e -> limpiar()));
        return p;
    }

    private JButton crearBtn(String texto, Color color, java.awt.event.ActionListener al) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(130, 36));
        b.addActionListener(al);
        return b;
    }

    private void cargarUsuarios() {
        cmbUsuario.removeAllItems();
        try (Statement st = Conexion.getConexion().createStatement();
             ResultSet rs = st.executeQuery("SELECT id, nombre FROM usuarios ORDER BY nombre")) {
            while (rs.next()) {
                cmbUsuario.addItem(rs.getInt("id") + " - " + rs.getString("nombre"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cargando usuarios: " + e.getMessage());
        }
    }

    private void cargarDatos() {
        modelo.setRowCount(0);
        String sql = """
            SELECT s.id, u.nombre, s.mes, s.anio,
                   s.salario_base, s.bonificacion, s.deducciones, s.salario_neto
            FROM salarios s JOIN usuarios u ON s.usuario_id = u.id
            ORDER BY s.anio DESC, s.mes
            """;
        try (Statement st = Conexion.getConexion().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id"), rs.getString("nombre"),
                    rs.getString("mes"), rs.getInt("anio"),
                    rs.getDouble("salario_base"), rs.getDouble("bonificacion"),
                    rs.getDouble("deducciones"), rs.getDouble("salario_neto")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cargando datos: " + e.getMessage());
        }
    }

    private int getUsuarioId() {
        if (cmbUsuario.getSelectedItem() == null) return -1;
        return Integer.parseInt(cmbUsuario.getSelectedItem().toString().split(" - ")[0]);
    }

    private void insertar() {
        if (cmbUsuario.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un usuario."); return;
        }
        String sql = "INSERT INTO salarios (usuario_id,mes,anio,salario_base,bonificacion,deducciones) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement(sql)) {
            ps.setInt(1, getUsuarioId());
            ps.setString(2, cmbMes.getSelectedItem().toString());
            ps.setInt(3, Integer.parseInt(txtAnio.getText().trim()));
            ps.setDouble(4, Double.parseDouble(txtSalarioBase.getText().replace(",", ".")));
            ps.setDouble(5, Double.parseDouble(txtBonificacion.getText().replace(",", ".")));
            ps.setDouble(6, Double.parseDouble(txtDeducciones.getText().replace(",", ".")));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Salario registrado.");
            limpiar(); cargarDatos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void actualizar() {
        if (idSeleccionado < 0) { JOptionPane.showMessageDialog(this, "Selecciona un registro."); return; }
        String sql = "UPDATE salarios SET mes=?,anio=?,salario_base=?,bonificacion=?,deducciones=? WHERE id=?";
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement(sql)) {
            ps.setString(1, cmbMes.getSelectedItem().toString());
            ps.setInt(2, Integer.parseInt(txtAnio.getText().trim()));
            ps.setDouble(3, Double.parseDouble(txtSalarioBase.getText().replace(",", ".")));
            ps.setDouble(4, Double.parseDouble(txtBonificacion.getText().replace(",", ".")));
            ps.setDouble(5, Double.parseDouble(txtDeducciones.getText().replace(",", ".")));
            ps.setInt(6, idSeleccionado);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Actualizado correctamente.");
            limpiar(); cargarDatos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void eliminar() {
        if (idSeleccionado < 0) { JOptionPane.showMessageDialog(this, "Selecciona un registro."); return; }
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar este registro?", "Confirmar",
            JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement("DELETE FROM salarios WHERE id=?")) {
            ps.setInt(1, idSeleccionado);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Eliminado.");
            limpiar(); cargarDatos();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void limpiar() {
        txtAnio.setText("2026");
        txtSalarioBase.setText("0.00");
        txtBonificacion.setText("0.00");
        txtDeducciones.setText("0.00");
        lblNeto.setText("$0.00");
        idSeleccionado = -1;
        tabla.clearSelection();
    }
}
