package crud;

import conexion.Conexion;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class GastoCRUD extends JFrame {

    private JComboBox<String> cmbUsuario, cmbCategoria, cmbMes;
    private JTextField txtAnio, txtDescripcion, txtMonto;
    private JTable tabla;
    private DefaultTableModel modelo;
    private int idSeleccionado = -1;

    private static final String[] CATEGORIAS = {
        "Alimentación","Vivienda/Arriendo","Transporte","Salud",
        "Educación","Entretenimiento","Ropa","Servicios públicos","Otros"
    };

    private static final String[] MESES = {
        "Enero","Febrero","Marzo","Abril","Mayo","Junio",
        "Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"
    };

    public GastoCRUD() {
        setTitle("Control de Gastos");
        setSize(920, 580);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(248, 250, 252));

        add(headerPanel(), BorderLayout.NORTH);
        add(formularioPanel(), BorderLayout.WEST);
        add(tablaPanel(), BorderLayout.CENTER);
        add(botonesPanel(), BorderLayout.SOUTH);

        cargarUsuarios();
        cargarDatos();
    }

    private JPanel headerPanel() {
        JPanel p = new JPanel();
        p.setBackground(new Color(146, 64, 14));
        p.setPreferredSize(new Dimension(920, 50));
        JLabel lbl = new JLabel("CONTROL DE GASTOS PERSONALES", SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lbl.setForeground(Color.WHITE);
        p.add(lbl);
        return p;
    }

    private JPanel formularioPanel() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(146, 64, 14)),
            "  Datos del Gasto  ", 0, 0,
            new Font("Segoe UI", Font.BOLD, 12), new Color(146, 64, 14)));
        p.setBackground(Color.WHITE);
        p.setPreferredSize(new Dimension(240, 430));

        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 8, 3, 8);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.gridx = 0;

        g.gridy = 0; p.add(new JLabel("Usuario:"), g);
        g.gridy = 1;
        cmbUsuario = new JComboBox<>();
        cmbUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(cmbUsuario, g);

        g.gridy = 2; p.add(new JLabel("Categoría:"), g);
        g.gridy = 3;
        cmbCategoria = new JComboBox<>(CATEGORIAS);
        cmbCategoria.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(cmbCategoria, g);

        g.gridy = 4; p.add(new JLabel("Descripción:"), g);
        g.gridy = 5;
        txtDescripcion = new JTextField(15);
        txtDescripcion.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(txtDescripcion, g);

        g.gridy = 6; p.add(new JLabel("Monto ($):"), g);
        g.gridy = 7;
        txtMonto = new JTextField("0.00", 10);
        txtMonto.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(txtMonto, g);

        g.gridy = 8; p.add(new JLabel("Mes:"), g);
        g.gridy = 9;
        cmbMes = new JComboBox<>(MESES);
        cmbMes.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(cmbMes, g);

        g.gridy = 10; p.add(new JLabel("Año:"), g);
        g.gridy = 11;
        txtAnio = new JTextField("2026", 10);
        txtAnio.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(txtAnio, g);

        return p;
    }

    private JScrollPane tablaPanel() {
        modelo = new DefaultTableModel(
            new String[]{"ID","Usuario","Categoría","Descripción","Monto","Mes","Año","Fecha"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tabla = new JTable(modelo);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tabla.setRowHeight(25);
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(new Color(146, 64, 14));
        tabla.getTableHeader().setForeground(Color.black);
        tabla.setSelectionBackground(new Color(254, 243, 199));

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                int row = tabla.getSelectedRow();
                idSeleccionado = Integer.parseInt(modelo.getValueAt(row, 0).toString());
                cmbCategoria.setSelectedItem(modelo.getValueAt(row, 2).toString());
                txtDescripcion.setText(modelo.getValueAt(row, 3).toString());
                txtMonto.setText(modelo.getValueAt(row, 4).toString());
                cmbMes.setSelectedItem(modelo.getValueAt(row, 5).toString());
                txtAnio.setText(modelo.getValueAt(row, 6).toString());
            }
        });

        JScrollPane sp = new JScrollPane(tabla);
        sp.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(146, 64, 14)),
            "  Lista de Gastos  ", 0, 0,
            new Font("Segoe UI", Font.BOLD, 12), new Color(146, 64, 14)));
        return sp;
    }

    private JPanel botonesPanel() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        p.setBackground(new Color(248, 250, 252));
        p.add(crearBtn("Agregar",    new Color(21, 128, 61),  e -> insertar()));
        p.add(crearBtn("Actualizar", new Color(146, 64, 14),  e -> actualizar()));
        p.add(crearBtn("Eliminar",   new Color(185, 28, 28),  e -> eliminar()));
        p.add(crearBtn("Limpiar",    new Color(30, 58, 138),  e -> limpiar()));
        return p;
    }

    private JButton crearBtn(String texto, Color color, java.awt.event.ActionListener al) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(130, 36));
        b.addActionListener(al);
        return b;
    }

    private void cargarUsuarios() {
        cmbUsuario.removeAllItems();
        try (Statement st = Conexion.getConexion().createStatement();
             ResultSet rs = st.executeQuery("SELECT id, nombre FROM usuarios ORDER BY nombre")) {
            while (rs.next()) {
                cmbUsuario.addItem(rs.getInt("id") + " - " + rs.getString("nombre"));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cargando usuarios: " + e.getMessage());
        }
    }

    private void cargarDatos() {
        modelo.setRowCount(0);
        String sql = """
            SELECT g.id, u.nombre, g.categoria, g.descripcion, g.monto, g.mes, g.anio, g.fecha
            FROM gastos g JOIN usuarios u ON g.usuario_id = u.id
            ORDER BY g.anio DESC, g.mes, g.fecha DESC
            """;
        try (Statement st = Conexion.getConexion().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id"), rs.getString("nombre"),
                    rs.getString("categoria"), rs.getString("descripcion"),
                    rs.getDouble("monto"), rs.getString("mes"),
                    rs.getInt("anio"), rs.getString("fecha")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error cargando datos: " + e.getMessage());
        }
    }

    private int getUsuarioId() {
        if (cmbUsuario.getSelectedItem() == null) return -1;
        return Integer.parseInt(cmbUsuario.getSelectedItem().toString().split(" - ")[0]);
    }

    private void insertar() {
        if (cmbUsuario.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un usuario."); return;
        }
        String sql = "INSERT INTO gastos (usuario_id,categoria,descripcion,monto,mes,anio) VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement(sql)) {
            ps.setInt(1, getUsuarioId());
            ps.setString(2, cmbCategoria.getSelectedItem().toString());
            ps.setString(3, txtDescripcion.getText().trim());
            ps.setDouble(4, Double.parseDouble(txtMonto.getText().replace(",", ".")));
            ps.setString(5, cmbMes.getSelectedItem().toString());
            ps.setInt(6, Integer.parseInt(txtAnio.getText().trim()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Gasto registrado.");
            limpiar(); cargarDatos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void actualizar() {
        if (idSeleccionado < 0) { JOptionPane.showMessageDialog(this, "Selecciona un gasto."); return; }
        String sql = "UPDATE gastos SET categoria=?,descripcion=?,monto=?,mes=?,anio=? WHERE id=?";
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement(sql)) {
            ps.setString(1, cmbCategoria.getSelectedItem().toString());
            ps.setString(2, txtDescripcion.getText().trim());
            ps.setDouble(3, Double.parseDouble(txtMonto.getText().replace(",", ".")));
            ps.setString(4, cmbMes.getSelectedItem().toString());
            ps.setInt(5, Integer.parseInt(txtAnio.getText().trim()));
            ps.setInt(6, idSeleccionado);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Gasto actualizado.");
            limpiar(); cargarDatos();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void eliminar() {
        if (idSeleccionado < 0) { JOptionPane.showMessageDialog(this, "Selecciona un gasto."); return; }
        if (JOptionPane.showConfirmDialog(this, "¿Eliminar este gasto?", "Confirmar",
            JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try (PreparedStatement ps = Conexion.getConexion().prepareStatement("DELETE FROM gastos WHERE id=?")) {
            ps.setInt(1, idSeleccionado);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Eliminado.");
            limpiar(); cargarDatos();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void limpiar() {
        txtDescripcion.setText("");
        txtMonto.setText("0.00");
        txtAnio.setText("2026");
        idSeleccionado = -1;
        tabla.clearSelection();
    }
}
