
-- ── Tabla: usuarios ──────────────────────────────────
CREATE TABLE IF NOT EXISTS usuarios (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre     TEXT    NOT NULL,
    cedula     TEXT    NOT NULL UNIQUE,
    correo     TEXT,
    contrasena TEXT    NOT NULL,
    fecha_reg  TEXT    DEFAULT (date('now'))
);

-- ── Tabla: salarios ──────────────────────────────────
CREATE TABLE IF NOT EXISTS salarios (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id   INTEGER NOT NULL,
    mes          TEXT    NOT NULL,
    anio         INTEGER NOT NULL,
    salario_base REAL    NOT NULL,
    bonificacion REAL    DEFAULT 0,
    deducciones  REAL    DEFAULT 0,
    salario_neto REAL    GENERATED ALWAYS AS
                 (salario_base + bonificacion - deducciones) VIRTUAL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- ── Tabla: gastos ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS gastos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id  INTEGER NOT NULL,
    categoria   TEXT    NOT NULL,
    descripcion TEXT,
    monto       REAL    NOT NULL,
    fecha       TEXT    DEFAULT (date('now')),
    mes         TEXT    NOT NULL,
    anio        INTEGER NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- ── Datos de prueba ───────────────────────────────────
INSERT INTO usuarios (nombre, cedula, correo, contrasena) VALUES
    ('Juan Pérez', '1234567890', 'juan@correo.com', 'pass123'),
    ('María López', '0987654321', 'maria@correo.com', 'pass456');

INSERT INTO salarios (usuario_id, mes, anio, salario_base, bonificacion, deducciones) VALUES
    (1, 'Mayo', 2026, 3500000, 200000, 350000),
    (2, 'Mayo', 2026, 2800000, 100000, 280000);

INSERT INTO gastos (usuario_id, categoria, descripcion, monto, mes, anio) VALUES
    (1, 'Alimentación',    'Mercado mensual',       600000, 'Mayo', 2026),
    (1, 'Vivienda/Arriendo', 'Arriendo apartamento', 900000, 'Mayo', 2026),
    (1, 'Transporte',      'Pasajes y gasolina',    200000, 'Mayo', 2026),
    (1, 'Servicios públicos', 'Agua, luz, internet', 250000, 'Mayo', 2026),
    (1, 'Entretenimiento', 'Netflix, salidas',      120000, 'Mayo', 2026),
    (2, 'Alimentación',    'Mercado mensual',       500000, 'Mayo', 2026),
    (2, 'Vivienda/Arriendo', 'Arriendo',             750000, 'Mayo', 2026),
    (2, 'Salud',           'Medicamentos',           80000, 'Mayo', 2026);
