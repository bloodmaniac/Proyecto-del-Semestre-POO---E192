package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Conexion {

    private static final String URL = "jdbc:sqlite:salary_control.db";
    private static Connection instancia = null;

    // Singleton - una sola conexión
    public static Connection getConexion() {
        try {
            if (instancia == null || instancia.isClosed()) {
                Class.forName("org.sqlite.JDBC");
                instancia = DriverManager.getConnection(URL);
                System.out.println("✅ Conexión SQLite establecida.");
                crearTablas(instancia);
            }
        } catch (ClassNotFoundException e) {
            System.err.println("❌ Driver SQLite no encontrado: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("❌ Error de conexión: " + e.getMessage());
        }
        return instancia;
    }

    private static void crearTablas(Connection conn) {
        String sqlUsuarios = """
            CREATE TABLE IF NOT EXISTS usuarios (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre     TEXT    NOT NULL,
                cedula     TEXT    NOT NULL UNIQUE,
                correo     TEXT,
                contrasena TEXT    NOT NULL,
                fecha_reg  TEXT    DEFAULT (date('now'))
            );
        """;

        String sqlSalarios = """
            CREATE TABLE IF NOT EXISTS salarios (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id   INTEGER NOT NULL,
                mes          TEXT    NOT NULL,
                anio         INTEGER NOT NULL,
                salario_base REAL    NOT NULL,
                bonificacion REAL    DEFAULT 0,
                deducciones  REAL    DEFAULT 0,
                salario_neto REAL    GENERATED ALWAYS AS
                             (salario_base + bonificacion - deducciones) VIRTUAL,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
            );
        """;

        String sqlGastos = """
            CREATE TABLE IF NOT EXISTS gastos (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id  INTEGER NOT NULL,
                categoria   TEXT    NOT NULL,
                descripcion TEXT,
                monto       REAL    NOT NULL,
                fecha       TEXT    DEFAULT (date('now')),
                mes         TEXT    NOT NULL,
                anio        INTEGER NOT NULL,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
            );
        """;

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(sqlUsuarios);
            stmt.execute(sqlSalarios);
            stmt.execute(sqlGastos);
            System.out.println("✅ Tablas verificadas/creadas correctamente.");
        } catch (SQLException e) {
            System.err.println("❌ Error creando tablas: " + e.getMessage());
        }
    }

    public static void cerrarConexion() {
        try {
            if (instancia != null && !instancia.isClosed()) {
                instancia.close();
                System.out.println("🔒 Conexión cerrada.");
            }
        } catch (SQLException e) {
            System.err.println("Error cerrando conexión: " + e.getMessage());
        }
    }
}
